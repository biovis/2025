Description: The supplementary material includes full-resolution images for each figure presented in the paper, along with a video demonstrating the visualization system.
Size: 5.71 MB
Player Information: N/A or basic software provided by most OS to view image or video files.
Extended Object List:
- figure1.png
- figure2.png
- figure3.png
- figure4.png
- video.png
Contact Information: tim.markwardt@googlemail.com
