Description:
This repository contains supplementary materials that accompany the abstract submission to the Bio+MedVis Redesign Challenge @ IEEE VIS 2025, MRSight: Visualizing Insight for Magnetic Resonance Spectroscopy.

Size:
The total size of all objects is 10.1 MB.

Player information:
PNG and PDF files can be opened with a built-in image viewer such as Preview Version 11.0.
MP4 files can be opened with a video player such as VLC media player Version 3.0.21.

Extended object list:
Included in this repository are:
- Teaser figure from the abstract submission (fig01_teaser.png)
- Additional figures showing the three different views of spectral output in MRSight:
	- The default views of all visualization in MRSight, including the Group Average View of spectral output (supp01_default-views.png)
	- Individual Spectra View, zoomed into peaks using the sliders at the bottom of the graph (supp02_individual-spectra-zoomed.png)
	- Stacked Spectra View. When hovering over an individual spectra in the stack, all graphs are focused on data related to that single spectra (supp03_stacked-spectra-focused.png)
        - Grouped Comparison View. Participant spectra can be grouped into folders (such as control and treatment) such that summaries/aggregates can be compared across participant groups. (supp04_grouped-comparison.png)
- Video walkthrough of the MRSight interface (supp05_video-walkthrough.mp4)
- PDF copy of the abstract submission (biomedvis2025_mrsight.pdf)

Contact information:
Please contact Ke Er Amy Zhang (ke.zhang@uib.no) in case of questions regarding the supplementary material.